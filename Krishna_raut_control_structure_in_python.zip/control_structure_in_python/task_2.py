#Program to add every number from 1 to 50
a=1
b=50
total=0
for i in range(a,b+1):
    total=total+i

print(f"The sum of numbers from 1 to 50: {total}")